from django.apps import AppConfig


class ViewcrudConfig(AppConfig):
    name = 'viewcrud'
